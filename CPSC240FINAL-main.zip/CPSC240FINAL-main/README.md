# CPSC240FINAL
# Sample dialogue

### Welcome to the Electric Power Program by Luis Alvarado

### The time on the clock is now 384819342 tics.
### We turn your night into day.
### Please enter the emf value (volts):   35.75
### Please enter the resistance (ohms):   6.5
### The computed current is 5.5000 amps
### The Electric Power will send the current to the caller.
### The end time on the clock is now 385734198 tics.

### The caller received this number 5.5000 and will keep it.
### A zero will be sent to the OS as a signal of success.
